let heroes = [["Axe", "Tank"], ["Crystal Maiden", "Support"]];

function displayHeroes() {
    const heroesContainer = document.getElementById('heroesContainer');

    heroesContainer.innerHTML = '';

    for (let i = 0; i < heroes.length; i++) {
        const heroDiv = document.createElement('div');

        heroDiv.innerHTML = `<h3>${heroes[i][0]}</h3><p>${heroes[i][1]}</p>`;
        heroDiv.className = 'card';
        heroesContainer.appendChild(heroDiv);
    }
}

function addHeroCard() {
    let nameInput = document.getElementById('heroName').value;
    let classInput = document.getElementById('heroClass').value;
    const newHero = [nameInput.value, classInput.value];


    if (nameInput.value.trim() !== "" && classInput.value.trim() !== "") {
        heroes.push(newHero);
        displayHeroes();
    } else {
        alert('Заполните все поля!')
    }

    nameInput.value = '';
    classInput.value = '';
}

displayHeroes()

document.getElementById('addButton').addEventListener('click', addHeroCard);
